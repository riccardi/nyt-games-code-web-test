// See https://github.com/NYTimes/kyt/blob/master/docs/kytConfig.md

module.exports = {
  reactHotLoader: true,
  modifyWebpackConfig: baseConfig => (baseConfig),
}
